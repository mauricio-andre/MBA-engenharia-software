export const ptBR = {
    welcome: 'Bem-vindo, {{name}}!',
    loading: 'Carregando',
    github: 'Github',

    //SearchScreen
    searchScreenInputPlaceHolder: 'Digite aqui seu usuário do Github',
    searchScreenButtonText: 'Pesquisar',

    //ProfileScreen
    profileScreenFollowers: 'Seguidores',
    profileScreenFollowing: 'Seguindo',
};

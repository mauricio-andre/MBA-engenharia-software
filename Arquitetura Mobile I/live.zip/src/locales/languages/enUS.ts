export const enUS = {
    welcome: 'Welcome, {{name}}!',
    github: 'Github',
    loading: 'Carregando',

    //SearchScreen
    searchScreenInputPlaceHolder: 'Enter your Github username here',
    searchScreenButtonText: 'Search',

    //ProfileScreen
    profileScreenFollowers: 'Followers',
    profileScreenFollowing: 'Following',
};

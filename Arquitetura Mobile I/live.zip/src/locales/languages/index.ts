import { enUS } from './enUS';
import { ptBR } from './ptBR';

export const resources = {
    ptBR: {
        translation: ptBR,
    },
    enUS: {
        translation: enUS,
    },
};

export const images = {
    uspLogo: require('./images/usp.webp'),
};

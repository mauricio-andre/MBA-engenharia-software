module.exports = {
    root: true,
    extends: '@react-native',
    plugins: ['import'],
    rules: {
        'import/order': [
            'error',
            {
                'groups': ['builtin', 'external', 'internal'],
                'pathGroups': [
                    {
                        'pattern': 'react+(|-native)',
                        'group': 'external',
                        'position': 'before',
                    },
                ],
                'pathGroupsExcludedImportTypes': ['react'],
                'newlines-between': 'always',
                'alphabetize': {
                    'order': 'asc',
                    'caseInsensitive': true,
                },
            },
        ],
    },
};

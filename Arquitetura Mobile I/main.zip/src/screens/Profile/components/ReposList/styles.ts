import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    reposFlatList: {
        gap: 10,
        paddingHorizontal: 10,
    },
});
